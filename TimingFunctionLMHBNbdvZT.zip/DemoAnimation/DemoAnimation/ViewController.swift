//
//  ViewController.swift
//  DemoAnimation
//
//  Created by Lương Nhật Lâm on 8/16/16.
//  Copyright © 2016 luongnhatlam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var redView: UIView!
    
    @IBOutlet weak var blueView: UIView!
    
    @IBOutlet weak var pinkView: UIView!
    
    @IBOutlet weak var orangeView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
    }
    
    @IBAction func RunAction(sender: AnyObject) {
        let duration:NSTimeInterval = 2.0
        
        UIView.animateWithDuration(duration, delay: 0.0, options: UIViewAnimationOptions.CurveLinear, animations: {
            
            self.redView.center.x = 300
            
            }, completion: nil)
        
        UIView.animateWithDuration(duration, delay: 0.0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
            
            self.blueView.center.x = 300
            
            }, completion: nil)
        
        UIView.animateWithDuration(duration, delay: 0.0, options: UIViewAnimationOptions.CurveEaseOut, animations: {
            
            self.pinkView.center.x = 300
            
            }, completion: nil)

        UIView.animateWithDuration(duration, delay: 0.0, options: UIViewAnimationOptions.CurveEaseInOut, animations: {
            
            self.orangeView.center.x = 300
            
            }, completion: nil)


    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

