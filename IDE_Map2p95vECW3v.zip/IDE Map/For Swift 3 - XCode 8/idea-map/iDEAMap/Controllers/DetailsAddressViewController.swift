//
//  DetailsAddressViewController.swift
//  iDEAMap
//
//  Created by Lương Nhật Lâm on 8/17/16.
//  Copyright © 2016 IDEAcademy. All rights reserved.
//

import UIKit
import CoreLocation
import SafariServices

class DetailsAddressViewController: BaseViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var labelName: UILabel!
    
    @IBOutlet weak var labelAddress: UILabel!
    
    @IBOutlet weak var labelCallUber: UILabel!
    
    @IBOutlet weak var buttonCallUber: UIButton!
    
    @IBOutlet weak var buttonCallPhone: UIButton!
    
    @IBOutlet weak var goToIDEAImageView: UIImageView!
    
    let downloadQueue = DispatchQueue(label: "download.queue")
    
    var currentLocation:CLLocationCoordinate2D?
    var location:Location?
    var isFirstLoad:Bool = true
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationController?.navigationBar.layer.opacity = 0

    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        NotificationCenter.default.addObserver(forName: NSNotification.Name.UIApplicationDidBecomeActive, object: nil, queue: nil, using: {(notif) in
            self.navigationController?.navigationBar.layer.opacity = 0

        })
        
        self.navigationController?.navigationBar.layer.opacity = 0
        
        if isFirstLoad {
            self.imageView.image = nil
            isFirstLoad = false
            loadData()
        }
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.navigationBar.layer.opacity = 1
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        labelName.text = ""
        labelAddress.text = ""
        labelCallUber.isHidden = true
        buttonCallUber.isHidden = true
        buttonCallPhone.isHidden = true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func loadData(){
        
        guard let location = location else { return }
        
        self.imageView.backgroundColor = mainColor
        self.imageView.backgroundColor = mainColor
        
        downloadQueue.async {
            if let data = try? Data(contentsOf: URL(string: (location.imageURL)!)!) {
                
                DispatchQueue.main.async(execute: {
                    
                    if let image = UIImage(data: data) {
                        
                        self.imageView.backgroundColor = UIColor.clear
                        self.imageView.image = image
                        self.goToIDEAImageView.backgroundColor = UIColor.clear
                        self.goToIDEAImageView.image = image
                    }
                })
            } else {
                
            }
        }
        self.labelName.text = self.location?.name
        self.labelAddress.text = self.location?.address
        self.labelCallUber.isHidden = false
        self.buttonCallUber.isHidden = false
        self.buttonCallPhone.isHidden = false
    }
    
    @IBAction func callUberAction(_ sender: AnyObject) {
        
        if let currentLocation = self.currentLocation , let location = self.location {
            
        let pickupLoc = CLLocationCoordinate2D(latitude: currentLocation.latitude, longitude: currentLocation.longitude)
            
        let dropOffLoc = CLLocationCoordinate2D(latitude: location.latitude, longitude: location.longitude)
            
        let uberService = IDEUberService(clientID: "04YbEhsN-VB9HJRmq3tgvs5N4_k2_eWx")
            
        uberService.goToUberApp(pickupLocation: pickupLoc, dropOffLocation: dropOffLoc)
            
        }
    }
    
    @IBAction func callAction(_ sender: AnyObject) {
        
        guard let location = location else { return }
        guard let trimmedPhoneNumber = location.phone?.trimmingCharacters(in: CharacterSet.whitespaces) else { return }
        
        let phoneReplaced = trimmedPhoneNumber.replacingOccurrences(of: " ", with: "")
    
            if UIApplication.shared.canOpenURL(URL(string: "tel://\(phoneReplaced)")!) {
                
                UIApplication.shared.openURL(URL(string:  "tel://\(phoneReplaced)")!)
        }
        
    }
    
    @IBAction func backAction(_ sender: AnyObject) {
        let _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func gotoIDEA(_ sender: AnyObject) {
        let svc = SFSafariViewController(url: URL(string: "http://form.ide.academy/?ref=app-map")!)
        
        self.present(svc, animated: true, completion: nil)
    }
    
}

