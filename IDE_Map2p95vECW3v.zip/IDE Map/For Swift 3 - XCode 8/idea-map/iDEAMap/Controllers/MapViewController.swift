//
//  MapViewController.swift
//  iDEAMap
//
//  Created by Bao on 8/17/16.
//  Copyright © 2016 IDEAcademy. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import Firebase

class MapViewController: BaseViewController {
    
    // MARK: Outlets
    
    @IBOutlet weak var mapView: MKMapView!
    
    @IBOutlet weak var mapTypeSegment: UISegmentedControl!
    
    @IBOutlet weak var directView: UIView!
    
    @IBOutlet weak var blurEffectImageView: UIImageView!
    
    // Global Variables
    
    var locationManager =  CLLocationManager()
    
    var currentLocation: CLLocation?
    
    var destinationLocation: CLLocationCoordinate2D?
    
    var locationArray: [Location] = [Location]()
    
    var isFirstLoad = true
    
    let locationImageCache:NSCache<AnyObject,AnyObject> = NSCache<AnyObject,AnyObject>()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        if isFirstLoad {
            isFirstLoad = false
            mapTypeSegment.isUserInteractionEnabled = false
            loadData()
            self.navigationItem.setHidesBackButton(true, animated: false)
            self.directView.isHidden = true
            self.blurEffectImageView.isHidden = true
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Functions
    
    // Load Data from Firebase Database
    
    func loadData() {
        if let path: String = Bundle.main.path(forResource: "ideamap", ofType: "json") {
            
            if let jsonData:NSData = NSData(contentsOfFile: path) {
                
                do {
                    
                    if let result: [String:AnyObject] = try JSONSerialization.jsonObject(with: jsonData as Data, options: .mutableContainers) as? [String:AnyObject] {
                        //print(result["Locations"])
                        if let locationDict = result["Locations"] as? [String:AnyObject] {
                            //print(locationDict)
                            for locationData in locationDict {
                                
                                if let locationItem = locationData.value as? [String:AnyObject] {
                                    
                                    if let location = Location(id: locationData.key, locationDict: locationItem) {
                                        
                                        self.locationArray.append(location)
                                    }
                                }
                            }
                            
                            self.setUpMapView()
                        }
                    }
                } catch {
                    
                    print(error.localizedDescription)
                }
            }
        }
    }
    
    func setAllAnnotationsForMapView(locationArray: [Location], locationType: String) -> [CustomAnnotation]? {
        
        var annotationArray: [CustomAnnotation] = [CustomAnnotation]()
        
        for location in locationArray {
            
            if location.type == locationType || locationType == "all" {
                
                let annotation = CustomAnnotation(location: location)
                
                annotationArray.append(annotation)
            }
        }
        
        return annotationArray
    }
    
    func setUpMapView() {
        
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        locationManager.delegate = self
        
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestAlwaysAuthorization()
        
        mapView.delegate = self
        mapView.userTrackingMode = .follow
        
        if let annotations = setAllAnnotationsForMapView(locationArray: locationArray, locationType: "all") {
            mapView.addAnnotations(annotations)
        }
        mapTypeSegment.isUserInteractionEnabled = true
    }
    
    func drawDirectionFromTwoLocations(sourceLocation: CLLocationCoordinate2D, destinationLocation: CLLocationCoordinate2D) {
        
        //1
        let sourcePlacemark = MKPlacemark(coordinate: sourceLocation, addressDictionary: nil)
        let destinationPlacemark = MKPlacemark(coordinate: destinationLocation, addressDictionary: nil)
        //2
        let sourceMapItem = MKMapItem(placemark: sourcePlacemark)
        let detinationMapItem = MKMapItem(placemark: destinationPlacemark)
        //3
        let directionRequest = MKDirectionsRequest()
        directionRequest.source = sourceMapItem
        directionRequest.destination = detinationMapItem
        directionRequest.transportType = .automobile
        //4
        let directions = MKDirections(request: directionRequest)
        directions.calculate { (response, error) in
            if error == nil {
                if let route = response?.routes.first {

                    self.mapView.add(route.polyline, level: .aboveRoads)
                    let rect = route.polyline.boundingMapRect
                    self.mapView.setVisibleMapRect(rect, edgePadding: UIEdgeInsetsMake(40, 40, 20, 20), animated: true)
                    self.directView.isHidden = true
                    self.blurEffectImageView.isHidden = true
                }
            } else {
                print(error?.localizedDescription)
            }
        }
    }
    
    // MARK: Actions
    
    @IBAction func mapTypeSegmentAction(_ sender: AnyObject) {
        
        self.directView.isHidden = true
        self.blurEffectImageView.isHidden = true
        mapView.removeAnnotations(mapView.annotations)
        mapView.removeOverlays(mapView.overlays)
        var annotations = [CustomAnnotation]()
        if mapTypeSegment.selectedSegmentIndex == 0 {
            
            annotations = setAllAnnotationsForMapView(locationArray: locationArray, locationType: "all")!
        } else if mapTypeSegment.selectedSegmentIndex == 1  {
            
            annotations = setAllAnnotationsForMapView(locationArray: locationArray, locationType: "coffee")!
        }
        else if mapTypeSegment.selectedSegmentIndex == 2 {
            
             annotations = setAllAnnotationsForMapView(locationArray: locationArray, locationType: "restaurant")!
        } else {
            
             annotations = setAllAnnotationsForMapView(locationArray: locationArray, locationType: "hotel")!
        }
        //Không dùng hàm show do sẽ có animation tự động zoom MapView
        //mapView.showAnnotations(annotations, animated: false)
        mapView.addAnnotations(annotations)
    }
    
    @IBAction func userCurrentLocationButton(_ sender: AnyObject) {
        
        locationManager.startUpdatingLocation()
    }
    
    @IBAction func hiddenDirectViewButton(_ sender: AnyObject) {
        
        self.directView.isHidden = true
        self.blurEffectImageView.isHidden = true
    }
    
    @IBAction func directButton(_ sender: AnyObject) {
        
        if let destinationLocation = destinationLocation {
            
            mapView.removeOverlays(mapView.overlays)
            drawDirectionFromTwoLocations(sourceLocation: CLLocationCoordinate2DMake((locationManager.location?.coordinate.latitude)!, (locationManager.location?.coordinate.longitude)!), destinationLocation: destinationLocation)
        }
    }
    
    @IBAction func callDirectButton(_ sender: AnyObject) {
        
        if let selectedAnnotation = mapView.selectedAnnotations.first as? CustomAnnotation {
            
            if let phone = selectedAnnotation.placeLocation.phone {
                
                let phoneNumber = phone.trimAndReplaceSpaceCharacterInString(originalString: phone)
                if UIApplication.shared.canOpenURL(URL(string: "tel://\(phoneNumber)")!) {
                    
                    UIApplication.shared.openURL(URL(string:  "tel://\(phoneNumber)")!)
                    
                }
            }
        }
    }
}

extension MapViewController: MKMapViewDelegate {
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        
        let renderer = MKPolylineRenderer(overlay: overlay)
        
        if let selectedAnnotation = mapView.selectedAnnotations.first as? CustomAnnotation {
            
            let type = selectedAnnotation.placeLocation.type
                if type == "restaurant" {
                    
                    renderer.strokeColor = UIColor.blue
                } else if type == "coffee" {
                    
                    renderer.strokeColor = UIColor.brown
                } else {
                    
                    renderer.strokeColor = UIColor(colorLiteralRed: 253.0 / 255.0, green: 103.0 / 255.0, blue: 102.0 / 255.0, alpha: 1.0)
                }
        }
        
        renderer.lineWidth = 2.0
        return renderer
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        if let myAnnotation = annotation as? CustomAnnotation {
            
            var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: "CustomPinAnnotationView")
            if pinView == nil {
                pinView = MKAnnotationView(annotation: myAnnotation, reuseIdentifier: "CustomPinAnnotationView")
                pinView?.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
                pinView?.canShowCallout = true
                pinView?.calloutOffset = CGPoint(x: 0.0, y: 4.0)
                pinView?.contentMode = .scaleAspectFill
            } else {
                
                pinView?.annotation = annotation
            }
            
            pinView?.image = myAnnotation.image
            
            return pinView
        }
        return nil
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        
        let detailVC = self.storyboard?.instantiateViewController(withIdentifier: "detailVC") as! DetailsAddressViewController
        if let myLocationAnnotation = view.annotation as? CustomAnnotation {
            detailVC.location = myLocationAnnotation.placeLocation
            if let currentLocation = locationManager.location?.coordinate {
                detailVC.currentLocation = currentLocation
            }
        }
        
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {

        if let myAnnotation = view.annotation as? CustomAnnotation {
            self.directView.isHidden = false
            self.blurEffectImageView.isHidden = false
            destinationLocation = CLLocationCoordinate2D()
            destinationLocation = view.annotation?.coordinate
            let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
            imageView.contentMode = .scaleAspectFill
            
            imageView.backgroundColor = UIColor.gray
            
            if let dowloadedIMG = self.locationImageCache.object(forKey: myAnnotation.title! as AnyObject) as? UIImage {
                let newResizedImage = dowloadedIMG.scaleImage(newSize: CGSize(width: 50, height: 50))
                imageView.image = newResizedImage
            } else {
                
                DispatchQueue.global().async {
                    if let myAnnotationImageURL = myAnnotation.placeLocation.imageURL {
                        if let imageURL = URL(string: myAnnotationImageURL ) {
                            if let imageData = try? Data(contentsOf: imageURL) {
                                DispatchQueue.main.async(execute: {
                                    if let image = UIImage(data: imageData) {
                                        imageView.backgroundColor = UIColor.clear
                                        let newResizedImage = image.scaleImage(newSize: CGSize(width: 50, height: 50))
                                        imageView.image = newResizedImage
                                        self.locationImageCache.setObject(image, forKey: myAnnotation.title! as AnyObject)
                                    }
                                })
                            }
                        }
                    }
                }
            }
            
            view.leftCalloutAccessoryView = imageView
        }
    }
}

extension MapViewController: CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let currentLocation = locations.last
        
        var zoomLocation = CLLocationCoordinate2D()
        zoomLocation.latitude = (currentLocation?.coordinate.latitude)!
        zoomLocation.longitude = (currentLocation?.coordinate.longitude)!
        
        let viewRegion = MKCoordinateRegionMakeWithDistance(zoomLocation, 2000, 2000)
        
        mapView.setRegion(viewRegion, animated: true)
        locationManager.stopUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        
        switch status {
            
        case .notDetermined:
            locationManager.requestAlwaysAuthorization()
            break
        case .authorizedWhenInUse:
            locationManager.startUpdatingLocation()
            break
        case .authorizedAlways:
            locationManager.startUpdatingLocation()
            break
        case .restricted:
            break
        case .denied:
            break
        }
    }
    
}
