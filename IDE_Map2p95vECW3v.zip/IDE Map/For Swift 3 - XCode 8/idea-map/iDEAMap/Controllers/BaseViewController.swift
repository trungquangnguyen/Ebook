//
//  BaseViewController.swift
//  iDEAMap
//
//  Created by Bao on 8/18/16.
//  Copyright © 2016 IDEAcademy. All rights reserved.
//

import UIKit
import Firebase

class BaseViewController: UIViewController {

    // MARK: Instance Variables
    
    lazy var firebaseReference = FIRDatabase.database().reference()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Functions
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
