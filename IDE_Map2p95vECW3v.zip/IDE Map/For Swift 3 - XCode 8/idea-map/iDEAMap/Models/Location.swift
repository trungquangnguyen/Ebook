//
//  Location.swift
//  iDEAMap
//
//  Created by Bao on 8/17/16.
//  Copyright © 2016 IDEAcademy. All rights reserved.
//

import Foundation

struct Location{
    var id: String
    var address: String
    var name: String
    var longitude: Double
    var latitude: Double
    var type: String
    var imageURL: String?
    var phone: String?
    
    
    init?(id: String, locationDict: [String:AnyObject]) {
        
        guard let name = locationDict["name"] as? String, let address = locationDict["address"] as? String else { return nil }
        
        self.name = name
        self.address = address
        
        guard let longitude = locationDict["longitude"] as? Double else { return nil }
        guard  let latitude = locationDict["latitude"] as? Double  else { return nil }
        
        self.longitude = longitude
        self.latitude = latitude
        
        if let imageURL = locationDict["imageURL"] as? String {
            self.imageURL = imageURL
        }
        
        if let phone = locationDict["phone"] as? String {
            self.phone = phone
        }
        
        guard let type = locationDict["type"] as? String else { return nil }
        
        self.type = type
        self.id = id
    }
}
