//
//  ImageExtension.swift
//  iDEAMap
//
//  Created by Bao on 8/19/16.
//  Copyright © 2016 IDEAcademy. All rights reserved.
//

import Foundation
import UIKit

extension UIImage {
    
    func scaleImage(newSize: CGSize) -> UIImage {
        
        // Core Graphic
        
        UIGraphicsBeginImageContextWithOptions(newSize, false, 0.0)
        self.draw(in: CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height))
        let result: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        return result
        
    }
    
}
