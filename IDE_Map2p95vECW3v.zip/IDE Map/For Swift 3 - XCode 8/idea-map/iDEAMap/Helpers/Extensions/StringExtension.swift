//
//  StringExtension.swift
//  iDEAMap
//
//  Created by Bao on 8/19/16.
//  Copyright © 2016 IDEAcademy. All rights reserved.
//

import Foundation
import UIKit

extension String {
    
    func trimAndReplaceSpaceCharacterInString(originalString: String) -> String {
        let trimmedString = originalString.trimmingCharacters(in: CharacterSet.whitespaces)
        
        let stringReplaced = trimmedString.replacingOccurrences(of: " ", with: "")
        
        return stringReplaced
    }
    
}
