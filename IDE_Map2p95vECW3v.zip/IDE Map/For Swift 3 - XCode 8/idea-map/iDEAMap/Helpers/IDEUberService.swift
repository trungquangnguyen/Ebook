//
//  UberLink.swift
//  iDEAMap
//
//  Created by Lương Nhật Lâm on 8/17/16.
//  Copyright © 2016 IDEAcademy. All rights reserved.
//

import UIKit
import CoreLocation

final class IDEUberService {
    
    let clientID:String
    
    init(clientID:String) {
        
        self.clientID = clientID
        
    }
    
   private func deepLinkURIForUberAppWithClientID( pickupLatitude: Double, pickupLongitude:Double, pickupAddress:String?, dropOffLatitude:Double, dropOffLongitude:Double, dropOffAddress:String?) -> String {
        
        var URL:String = ""
        let customAllowedChars = NSCharacterSet(charactersIn: "").inverted
        
        if var pickupAddress = pickupAddress , !pickupAddress.isEmpty{
            pickupAddress = pickupAddress.addingPercentEncoding(withAllowedCharacters: customAllowedChars)!
        }
        
        if var dropOffAddress = dropOffAddress , !dropOffAddress.isEmpty {
            dropOffAddress = dropOffAddress.addingPercentEncoding(withAllowedCharacters: customAllowedChars)!
        }
        
        if pickupLatitude == 0 {
            URL = "uber://?action=setPickup&dropoff[longitude]=\(dropOffLongitude)&client_id=\(clientID)&dropoff[formatted_address]=\(dropOffAddress)&product_id=a1132c8c-c720-46c3-8534-2fcdd730040d&pickup=my_location&dropoff[latitude]=\(dropOffLatitude)"
        } else {
            URL = "uber://?action=setPickup&dropoff[latitude]=\(dropOffLatitude)&dropoff[longitude]=\(dropOffLongitude)&pickup[latitude]=\(pickupLatitude)&pickup[formatted_address]=\(pickupAddress)&client_id=\(clientID)&dropoff[formatted_address]=\(dropOffAddress)&product_id=a1132c8c-c720-46c3-8534-2fcdd730040d&pickup[longitude]=\(pickupLongitude)"
        }
        
        return URL
    }
    
    func goToUberApp(
        pickupLocation: CLLocationCoordinate2D,
        dropOffLocation:CLLocationCoordinate2D,
        pickupAddress:String? = nil,
        dropOffAddress:String? = nil ){
        
        let appstoreURL = "https://m.uber.com/sign-up?client_id=\(clientID)"
        
        var deepLink = deepLinkURIForUberAppWithClientID(
            pickupLatitude: pickupLocation.latitude,
            pickupLongitude: pickupLocation.longitude,
            pickupAddress: pickupAddress,
            dropOffLatitude: dropOffLocation.latitude,
            dropOffLongitude: dropOffLocation.longitude,
            dropOffAddress: dropOffAddress
        )
        
        deepLink = "fb://"
        
        if UIApplication.shared.canOpenURL(URL(string: deepLink)!) {
            UIApplication.shared.openURL(URL(string: deepLink)!)
        } else {
            UIApplication.shared.openURL(URL(string: appstoreURL)!)
        }
    }
}
