//
//  MapViewController.swift
//  ide-map-Xcode-7
//
//  Created by Bao on 8/23/16.
//  Copyright © 2016 luongnhatlam. All rights reserved.
//

import UIKit
import MapKit

class MapViewController: UIViewController {

    //MARK: Outlets
    
    @IBOutlet weak var mapView: MKMapView!
    
    @IBOutlet weak var mapTypeSegment: UISegmentedControl!
    
    @IBOutlet weak var directView: UIView!
    
    @IBOutlet weak var blurEffectImageView: UIImageView!
    
    //MARK: Global variables
    
    var locationManager =  CLLocationManager()
    
    var currentLocation: CLLocation?
    
    var destinationLocation: CLLocationCoordinate2D?
    
    var locationArray: [Location] = [Location]()
    
    var isFirstLoad = true
    
    let locationImageCache:NSCache = NSCache()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        if isFirstLoad {
            isFirstLoad = false
            mapTypeSegment.userInteractionEnabled = false
            loadData()
            self.navigationItem.setHidesBackButton(true, animated: false)
            self.directView.hidden = true
            self.blurEffectImageView.hidden = true
        }
    }

    func loadData() {
        if let path: String = NSBundle.mainBundle().pathForResource("ideamap", ofType: "json") {
            
            if let jsonData:NSData = NSData(contentsOfFile: path) {
                
                do {
                    
                    if let result: [String:AnyObject] = try NSJSONSerialization.JSONObjectWithData(jsonData, options: .MutableContainers) as? [String:AnyObject] {
                        //print(result["Locations"])
                        if let locationDict = result["Locations"] as? [String:AnyObject] {
                            //print(locationDict)
                            for locationData in locationDict {
                                
                                if let locationItem = locationData.1 as? [String:AnyObject] {
                                    
                                    if let location = Location(id: locationData.0, locationDict: locationItem) {
                                        
                                        self.locationArray.append(location)
                                    }
                                }
                            }
                            
                            self.setUpMapView()
                        }
                    }
                } catch {
                    
                    print(error)
                }
            }
        }
    }
    
    func setAllAnnotationsForMapView(locationArray: [Location], locationType: String) -> [CustomAnnotation]? {
        
        var annotationArray: [CustomAnnotation] = [CustomAnnotation]()
        
        for location in locationArray {
            
            if location.type == locationType || locationType == "all" {
                
                let annotation = CustomAnnotation(location: location)
                
                annotationArray.append(annotation)
            }
        }
        
        return annotationArray
    }
    
    func setUpMapView() {
        
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        locationManager.delegate = self
        
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestAlwaysAuthorization()
        
        mapView.delegate = self
        mapView.userTrackingMode = .Follow
        
        if let annotations = setAllAnnotationsForMapView(locationArray, locationType: "all") {
            mapView.addAnnotations(annotations)
        }
        mapTypeSegment.userInteractionEnabled = true
    }
    
    func drawDirectionFromTwoLocations(sourceLocation: CLLocationCoordinate2D, destinationLocation: CLLocationCoordinate2D) {
        
        //1
        let sourcePlacemark = MKPlacemark(coordinate: sourceLocation, addressDictionary: nil)
        let destinationPlacemark = MKPlacemark(coordinate: destinationLocation, addressDictionary: nil)
        //2
        let sourceMapItem = MKMapItem(placemark: sourcePlacemark)
        let detinationMapItem = MKMapItem(placemark: destinationPlacemark)
        //3
        let directionRequest = MKDirectionsRequest()
        directionRequest.source = sourceMapItem
        directionRequest.destination = detinationMapItem
        directionRequest.transportType = .Automobile
        //4
        let directions = MKDirections(request: directionRequest)
        directions.calculateDirectionsWithCompletionHandler({ (response, error) in
            
            if error == nil {
                if let route = response?.routes.first {
                    
                    self.mapView.addOverlay(route.polyline, level: .AboveRoads)
                    let rect = route.polyline.boundingMapRect
                    self.mapView.setVisibleMapRect(rect, edgePadding: UIEdgeInsetsMake(40, 40, 20, 20), animated: true)
                    self.directView.hidden = true
                    self.blurEffectImageView.hidden = true
                }
            } else {
                print(error?.localizedDescription)
            }
        })

    }
    
    //MARK: Actions
    
    @IBAction func mapTypeSegmentAction(sender: AnyObject) {
        
        self.directView.hidden = true
        self.blurEffectImageView.hidden = true
        mapView.removeAnnotations(mapView.annotations)
        mapView.removeOverlays(mapView.overlays)
        var annotations = [CustomAnnotation]()
        if mapTypeSegment.selectedSegmentIndex == 0 {
            
            annotations = setAllAnnotationsForMapView(locationArray, locationType: "all")!
        } else if mapTypeSegment.selectedSegmentIndex == 1  {
            
            annotations = setAllAnnotationsForMapView(locationArray, locationType: "coffee")!
        }
        else if mapTypeSegment.selectedSegmentIndex == 2 {
            
            annotations = setAllAnnotationsForMapView(locationArray, locationType: "restaurant")!
        } else {
            
            annotations = setAllAnnotationsForMapView(locationArray, locationType: "hotel")!
        }
        //Không dùng hàm show do sẽ có animation tự động zoom MapView
        //mapView.showAnnotations(annotations, animated: false)
        mapView.addAnnotations(annotations)
        
    }
    
    @IBAction func userCurrentLocationButton(sender: AnyObject) {
        
        locationManager.startUpdatingLocation()
    }
    
    @IBAction func hiddenDirectViewButton(sender: AnyObject) {
        
        self.directView.hidden = true
        self.blurEffectImageView.hidden = true
    }
    
    @IBAction func directButton(sender: AnyObject) {
        
        if let destinationLocation = destinationLocation {
            
            mapView.removeOverlays(mapView.overlays)
            drawDirectionFromTwoLocations(CLLocationCoordinate2DMake((locationManager.location?.coordinate.latitude)!, (locationManager.location?.coordinate.longitude)!), destinationLocation: destinationLocation)
        }
    }
    
    @IBAction func callDirectButton(sender: AnyObject) {
        
        if let selectedAnnotation = mapView.selectedAnnotations.first as? CustomAnnotation {
            
            if let phone = selectedAnnotation.placeLocation.phone {
                
                let phoneNumber = phone.trimAndReplaceSpaceCharacterInString(phone)
                if UIApplication.sharedApplication().canOpenURL(NSURL(string: "tel://\(phoneNumber)")!) {
                    
                    UIApplication.sharedApplication().openURL(NSURL(string:  "tel://\(phoneNumber)")!)
                    
                }
            }
        }
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension MapViewController: MKMapViewDelegate {
    
    func mapView(mapView: MKMapView, rendererForOverlay overlay: MKOverlay) -> MKOverlayRenderer {
        
        let renderer = MKPolylineRenderer(overlay: overlay)
        
        if let selectedAnnotation = mapView.selectedAnnotations.first as? CustomAnnotation {
            
            let type = selectedAnnotation.placeLocation.type
            if type == "restaurant" {
                
                renderer.strokeColor = UIColor.blueColor()
            } else if type == "coffee" {
                
                renderer.strokeColor = UIColor.brownColor()
            } else {
                
                renderer.strokeColor = UIColor(colorLiteralRed: 253.0 / 255.0, green: 103.0 / 255.0, blue: 102.0 / 255.0, alpha: 1.0)
            }
        }
        
        renderer.lineWidth = 2.0
        return renderer
    }
    
    func mapView(mapView: MKMapView, viewForAnnotation annotation: MKAnnotation) -> MKAnnotationView? {
        
        if let myAnnotation = annotation as? CustomAnnotation {
            
            var pinView = mapView.dequeueReusableAnnotationViewWithIdentifier("CustomPinAnnotationView")
            if pinView == nil {
                pinView = MKAnnotationView(annotation: myAnnotation, reuseIdentifier: "CustomPinAnnotationView")
                pinView?.rightCalloutAccessoryView = UIButton(type: .DetailDisclosure)
                pinView?.canShowCallout = true
                pinView?.calloutOffset = CGPoint(x: 0.0, y: 4.0)
                pinView?.contentMode = .ScaleAspectFill
            } else {
                
                pinView?.annotation = annotation
            }
            
            pinView?.image = myAnnotation.image
            
            return pinView
        }
        return nil
    }
    
    func mapView(mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        
        let detailVC = self.storyboard?.instantiateViewControllerWithIdentifier("detailVC") as! DetailsAddressViewController
        if let myLocationAnnotation = view.annotation as? CustomAnnotation {
            detailVC.location = myLocationAnnotation.placeLocation
            if let currentLocation = locationManager.location?.coordinate {
                detailVC.currentLocation = currentLocation
            }
        }
        
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
    
    func mapView(mapView: MKMapView, didSelectAnnotationView view: MKAnnotationView) {
        
        if let myAnnotation = view.annotation as? CustomAnnotation {
            self.directView.hidden = false
            self.blurEffectImageView.hidden = false
            destinationLocation = CLLocationCoordinate2D()
            destinationLocation = view.annotation?.coordinate
            let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
            imageView.contentMode = .ScaleAspectFill
            
            imageView.backgroundColor = UIColor.grayColor()
            
            if let dowloadedIMG = self.locationImageCache.objectForKey(myAnnotation.title! as AnyObject) as? UIImage {
                let newResizedImage = dowloadedIMG.scaleImage(CGSize(width: 50, height: 50))
                imageView.image = newResizedImage
            } else {
                
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), {
                    
                    if let myAnnotationImageURL = myAnnotation.placeLocation.imageURL {
                        
                        if let imageURL = NSURL(string: myAnnotationImageURL ) {
                            
                            if let imageData = NSData(contentsOfURL: imageURL) {
                                
                                dispatch_async(dispatch_get_main_queue(), {
                                    
                                    if let image = UIImage(data: imageData) {
                                        
                                        imageView.backgroundColor = UIColor.clearColor()
                                        let newResizedImage = image.scaleImage(CGSize(width: 50, height: 50))
                                        imageView.image = newResizedImage
                                        self.locationImageCache.setObject(image, forKey: myAnnotation.title! as AnyObject)
                                    }
                                })
                            }
                        }
                    }
                })
            }

            view.leftCalloutAccessoryView = imageView
        }
    }
    
}

extension MapViewController: CLLocationManagerDelegate {
    
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let currentLocation = locations.last
        
        var zoomLocation = CLLocationCoordinate2D()
        zoomLocation.latitude = (currentLocation?.coordinate.latitude)!
        zoomLocation.longitude = (currentLocation?.coordinate.longitude)!
        
        let viewRegion = MKCoordinateRegionMakeWithDistance(zoomLocation, 2000, 2000)
        
        mapView.setRegion(viewRegion, animated: true)
        locationManager.stopUpdatingLocation()
    }
    
    func locationManager(manager: CLLocationManager, didChangeAuthorizationStatus status: CLAuthorizationStatus) {
        
        switch status {
            
        case .NotDetermined:
            locationManager.requestAlwaysAuthorization()
            break
        case .AuthorizedWhenInUse:
            locationManager.startUpdatingLocation()
            break
        case .AuthorizedAlways:
            locationManager.startUpdatingLocation()
            break
        case .Restricted:
            break
        case .Denied:
            break
        }
    }
    
}






