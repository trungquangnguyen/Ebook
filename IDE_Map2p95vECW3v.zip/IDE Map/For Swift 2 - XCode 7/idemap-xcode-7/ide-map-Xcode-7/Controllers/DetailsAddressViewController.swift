//
//  DetailsAddressViewController.swift
//  iDEAMap
//
//  Created by Lương Nhật Lâm on 8/17/16.
//  Copyright © 2016 IDEAcademy. All rights reserved.
//

import UIKit
import CoreLocation
import SafariServices

class DetailsAddressViewController: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var labelName: UILabel!
    
    @IBOutlet weak var labelAddress: UILabel!
    
    @IBOutlet weak var labelCallUber: UILabel!
    
    @IBOutlet weak var buttonCallUber: UIButton!
    
    @IBOutlet weak var buttonCallPhone: UIButton!
    
    
    var currentLocation:CLLocationCoordinate2D?
    var location:Location?
    var isFirstLoad:Bool = true
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationController?.navigationBar.layer.opacity = 0

    }
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        NSNotificationCenter.defaultCenter().addObserverForName(UIApplicationDidBecomeActiveNotification, object: nil, queue: nil) { (notif) in
            self.navigationController?.navigationBar.layer.opacity = 0
        }
        
        self.navigationController?.navigationBar.layer.opacity = 0
        
        if isFirstLoad {
            self.imageView.image = nil
            isFirstLoad = false
            loadData()
        }
        
    }
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.navigationBar.layer.opacity = 1
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.labelName.text = self.location?.name
        self.labelAddress.text = self.location?.address

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func loadData(){
        
        guard let location = location else { return }
        
        self.imageView.backgroundColor = mainColor
        self.imageView.backgroundColor = mainColor
        
        dispatch_async(dispatch_get_global_queue(0, 0)) { 
            if let data = NSData(contentsOfURL: NSURL(string: (location.imageURL)!)!) {
                
                dispatch_async(dispatch_get_main_queue(), { 
                    if let image = UIImage(data: data) {
                        
                        self.imageView.backgroundColor = UIColor.clearColor()
                        self.imageView.image = image
                    }
                })
            } else {
                
            }
                
        }
    }
   
    
    @IBAction func callUberAction(sender: AnyObject) {
        if let currentLocation = self.currentLocation , let location = self.location {
            
            let pickupLoc = CLLocationCoordinate2D(latitude: currentLocation.latitude, longitude: currentLocation.longitude)
            
            let dropOffLoc = CLLocationCoordinate2D(latitude: location.latitude, longitude: location.longitude)
            
            let uberService = IDEUberService(clientID: "04YbEhsN-VB9HJRmq3tgvs5N4_k2_eWx")
            
            uberService.goToUberApp(pickupLoc, dropOffLocation: dropOffLoc)
            
        }
    }
    
    
    @IBAction func callAction(sender: AnyObject) {
        
        guard let location = location else { return }
        
        guard let trimmedPhoneNumber = location.phone?.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet()) else { return }
        
        let phoneReplaced = trimmedPhoneNumber.stringByReplacingOccurrencesOfString(" ", withString: "")
    
            if UIApplication.sharedApplication().canOpenURL(NSURL(string: "tel://\(phoneReplaced)")!) {
                
                UIApplication.sharedApplication().openURL(NSURL(string:  "tel://\(phoneReplaced)")!)
        }
        
    }

    @IBAction func backAction(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    @IBAction func gotoIDEA(sender: AnyObject) {
        let svc = SFSafariViewController(URL: NSURL(string: "http://form.ide.academy/?ref=app-map")!)
        
        self.presentViewController(svc, animated: true, completion: nil) 
    }
}

