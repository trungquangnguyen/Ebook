//
//  CustomAnnotation.swift
//  ide-map-Xcode-7
//
//  Created by Bao on 8/23/16.
//  Copyright © 2016 luongnhatlam. All rights reserved.
//

import UIKit
import MapKit

class CustomAnnotation: NSObject, MKAnnotation {
    
    var placeLocation: Location
    
    var coordinate: CLLocationCoordinate2D {
        return CLLocationCoordinate2D(latitude: placeLocation.latitude, longitude: placeLocation.longitude)
    }
    var title: String? {
        return placeLocation.name
    }
    
    var subtitle: String? {
        return placeLocation.address
    }
    
    var image: UIImage {
        return UIImage(named: "\(placeLocation.type)")!
    }
    
    init(location: Location) {
        
        self.placeLocation = location
    }
}
