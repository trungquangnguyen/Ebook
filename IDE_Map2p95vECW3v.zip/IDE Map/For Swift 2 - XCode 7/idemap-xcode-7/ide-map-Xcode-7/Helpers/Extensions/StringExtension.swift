//
//  StringExtension.swift
//  ide-map-Xcode-7
//
//  Created by Bao on 8/23/16.
//  Copyright © 2016 luongnhatlam. All rights reserved.
//

import Foundation
import UIKit

extension String {
    
    func trimAndReplaceSpaceCharacterInString(originalString: String) -> String {
        let trimmedString = originalString.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
        let stringReplaced = trimmedString.stringByReplacingOccurrencesOfString(" ", withString: "")
        
        return stringReplaced
    }
    
}
