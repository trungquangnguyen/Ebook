//
//  ImageExtension.swift
//  ide-map-Xcode-7
//
//  Created by Bao on 8/23/16.
//  Copyright © 2016 luongnhatlam. All rights reserved.
//

import Foundation
import UIKit

extension UIImage {
    
    func scaleImage(newSize: CGSize) -> UIImage {
        
        // Core Graphic
        
        UIGraphicsBeginImageContextWithOptions(newSize, false, 0.0)
        self.drawInRect(CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height))
        let result: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        return result
        
    }
}







